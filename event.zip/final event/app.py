from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import timedelta
import threading
import os
from flask import send_from_directory

app = Flask(__name__)
app.secret_key = 'tbfhxytfg564758'  # Used for session signing and encryption
app.permanent_session_lifetime = timedelta(days=30)  # Set session lifetime to 30 days

# Database connection function
db_lock = threading.Lock()
def get_db_connection():
    conn = sqlite3.connect('users.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def home():
    if 'user_id' in session:
        conn = get_db_connection()
        cur = conn.cursor()

        # Fetch user details
        cur.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
        user = cur.fetchone()

        # Check if the user exists
        if not user:
            return redirect(url_for('login'))  # Redirect to login if user not found

        # Fetch user's events
        cur.execute('SELECT * FROM events WHERE user_id = ?', (session['user_id'],))
        events = cur.fetchall()

        # Fetch guests for each event
        guests = {}
        for event in events:
            cur.execute('SELECT * FROM guests WHERE event_id = ?', (event['id'],))
            guests[event['id']] = cur.fetchall()

        # Fetch all items added by vendors
        cur.execute('SELECT i.*, v.name as vendor_name, v.email as vendor_email FROM items i JOIN vendors v ON i.vendor_id = v.id')
        items = cur.fetchall()

        conn.close()

        # Convert rows to dictionaries
        user = dict(user)
        events = [dict(event) for event in events]
        guests = {event_id: [dict(guest) for guest in guests] for event_id, guests in guests.items()}
        items = [dict(item) for item in items]

        # Render the user homepage with the user, events, guests, and items data
        return render_template('user_home.html', user=user, events=events, guests=guests, items=items)

    # If not logged in, show the index page
    return render_template('index.html')



@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        conn = get_db_connection()
        cur = conn.cursor()

        # Check if username or email already exists
        cur.execute('SELECT * FROM users WHERE email = ? OR username = ?', (email, username))
        user = cur.fetchone()

        if user:
            flash('Username or Email already registered.')
            return redirect(url_for('register'))

        # Insert user into the database
        cur.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', 
                    (username, email, hashed_password))
        conn.commit()
        conn.close()

        flash('Registration successful. Please log in.')
        return redirect(url_for('login'))

    return render_template('user_register.html')


# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM users WHERE email = ?', (email,))
        user = cur.fetchone()

        if user and check_password_hash(user['password'], password):
            session.permanent = True  # Make the session permanent (persistent after browser close)
            session['user_id'] = user['id']  # Store user ID in session
            return redirect(url_for('home'))
        else:
            flash('Invalid email or password.')

    return render_template('user_login.html')

# Logout route
@app.route('/logout')
def logout():
    session.pop('user_id', None)  # Remove user_id from session
    flash('You have been logged out.')
    return redirect(url_for('login'))

# Admin Registration route
@app.route('/vendor/register', methods=['GET', 'POST'])
def vendor_register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        category = request.form['category']
        hashed_password = generate_password_hash(password)

        conn = get_db_connection()
        cur = conn.cursor()

        # Check if email already exists
        cur.execute('SELECT * FROM vendors WHERE email = ?', (email,))
        admin = cur.fetchone()

        if admin:
            flash('Email already registered.')
            return redirect(url_for('vendor_register'))

        # Insert new admin into the database
        cur.execute('INSERT INTO vendors (name, email, password, category) VALUES (?, ?, ?, ?)', 
                    (name, email, hashed_password, category))
        conn.commit()
        conn.close()

        flash('Registration successful. Please log in.')
        return redirect(url_for('vendor_login'))

    return render_template('vendor_register.html')

# Admin Login route
@app.route('/vendor/login', methods=['GET', 'POST'])
def vendor_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM vendors WHERE email = ?', (email,))
        vendor = cur.fetchone()

        if vendor and check_password_hash(vendor['password'], password):
            session.permanent = True
            session['vendor_id'] = vendor['id']
            session['vendor_category'] = vendor['category']
            return redirect(url_for('vendor_home'))
        else:
            flash('Invalid email or password.')

    return render_template('vendor_login.html')


@app.route('/vendor')
def vendor_home():
    if 'vendor_id' in session:
        conn = sqlite3.connect('users.db')
        cur = conn.cursor()

        # Fetch vendor details
        cur.execute('SELECT id, name, email, category FROM vendors WHERE id = ?', (session['vendor_id'],))
        vendor = cur.fetchone()

        # Convert vendor tuple to a dictionary for easier access in the template
        vendor_dict = {
            'id': vendor[0],
            'name': vendor[1],
            'email': vendor[2],
            'category': vendor[3]
        }

        # Fetch the list of items added by the logged-in vendor
        cur.execute('SELECT id, product_image_url, product_name, product_price FROM items WHERE vendor_id = ?', (session['vendor_id'],))
        items = cur.fetchall()

        # Convert items from tuples to dictionaries
        items_list = []
        for item in items:
            items_list.append({
                'id': item[0],
                'product_image_url': item[1],
                'product_name': item[2],
                'product_price': item[3]
            })

        conn.close()

        return render_template('vendor_home.html', vendor=vendor_dict, items=items_list)

    return redirect(url_for('vendor_login'))

# Logout route
@app.route('/vendor/logout')
def vendor_logout():
    session.pop('vendor_id', None)
    session.pop('ventor_category', None)
    flash('You have been logged out.')
    return redirect(url_for('vendor_login'))

# Define the upload folder
UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')  # Create 'uploads' folder in the root directory
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Allow only specific file extensions for product images (like jpg, png)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# Helper function to check if file extension is allowed
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Route to add item
@app.route('/vendor/add_item', methods=['GET', 'POST'])
def add_item():
    if 'vendor_id' in session:
        if request.method == 'POST':
            product_name = request.form['product_name']
            product_price = request.form['product_price']
            vendor_id = session['vendor_id']  # Get vendor_id from session

            # Check if an image was uploaded
            if 'product_image' not in request.files:
                flash('No file part')
                return redirect(request.url)

            file = request.files['product_image']

            # If the user does not select a file, the browser submits an empty part without a filename
            if file.filename == '':
                flash('No selected file')
                return redirect(request.url)

            # If the file is valid, save it in the uploads folder
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

                product_image_url = f"/uploads/{filename}"  # Path to store in the database

                # Insert the product information into the database
                conn = sqlite3.connect('users.db')
                cur = conn.cursor()
                cur.execute('''
                    INSERT INTO items (vendor_id, product_image_url, product_name, product_price)
                    VALUES (?, ?, ?, ?)''', (vendor_id, product_image_url, product_name, product_price))
                conn.commit()
                conn.close()

                flash('Item added successfully!')
                return redirect(url_for('vendor_home'))

        return render_template('add_item.html')

    return redirect(url_for('vendor_login'))

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/delete_item/<int:item_id>', methods=['POST'])
def delete_item(item_id):
    if 'vendor_id' in session:
        conn = sqlite3.connect('users.db')
        cur = conn.cursor()

        # Delete the item from the database
        cur.execute('DELETE FROM items WHERE id = ? AND vendor_id = ?', (item_id, session['vendor_id']))
        conn.commit()
        conn.close()

        flash('Item deleted successfully.')
        return redirect(url_for('vendor_home'))

    return redirect(url_for('vendor_login'))

@app.route('/update_item/<int:item_id>', methods=['GET', 'POST'])
def update_item(item_id):
    if 'vendor_id' in session:
        conn = sqlite3.connect('users.db')
        cur = conn.cursor()

        if request.method == 'POST':
            product_name = request.form['product_name']
            product_price = request.form['product_price']

            # Handle image update if a new image is provided
            file = request.files.get('product_image')
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                product_image_url = filename
            else:
                # Retain the existing image URL if no new image is uploaded
                product_image_url = request.form['existing_image_url']

            # Update the item in the database
            cur.execute('''
                UPDATE items
                SET product_name = ?, product_price = ?, product_image_url = ?
                WHERE id = ? AND vendor_id = ?
            ''', (product_name, product_price, product_image_url, item_id, session['vendor_id']))
            conn.commit()
            conn.close()

            flash('Item updated successfully.')
            return redirect(url_for('vendor_home'))

        # Fetch the item to pre-fill the form
        cur.execute('SELECT id, product_image_url, product_name, product_price FROM items WHERE id = ? AND vendor_id = ?', (item_id, session['vendor_id']))
        item = cur.fetchone()
        conn.close()

        # Convert tuple to dictionary
        item_dict = {
            'id': item[0],
            'product_image_url': item[1],
            'product_name': item[2],
            'product_price': item[3]
        }

        return render_template('update_item.html', item=item_dict)

    return redirect(url_for('vendor_login'))

@app.route('/create_event', methods=['GET', 'POST'])
def create_event():
    if 'user_id' in session:
        if request.method == 'POST':
            event_name = request.form['event_name']
            event_date = request.form['event_date']
            num_guests = int(request.form['num_guests'])
            user_id = session['user_id']

            conn = sqlite3.connect('users.db')
            cur = conn.cursor()

            # Insert event
            cur.execute('''
                INSERT INTO events (event_name, event_date, user_id)
                VALUES (?, ?, ?)
            ''', (event_name, event_date, user_id))
            event_id = cur.lastrowid

            # Insert guests
            for i in range(num_guests):
                guest_name = request.form.get(f'guest_name_{i}')
                phone_number = request.form.get(f'phone_number_{i}')
                email = request.form.get(f'email_{i}')
                
                cur.execute('''
                    INSERT INTO guests (event_id, guest_name, phone_number, email, user_id)
                    VALUES (?, ?, ?, ?, ?)
                ''', (event_id, guest_name, phone_number, email, user_id))

            conn.commit()
            conn.close()

            flash('Event created successfully.')
            return redirect(url_for('home'))

        return render_template('create_event.html')

    return redirect(url_for('login'))

# Route to delete an event
@app.route('/delete_event/<int:event_id>', methods=['POST'])
def delete_event(event_id):
    if 'user_id' in session:
        conn = get_db_connection()
        cur = conn.cursor()

        # Delete guests associated with the event
        cur.execute('DELETE FROM guests WHERE event_id = ?', (event_id,))

        # Delete the event
        cur.execute('DELETE FROM events WHERE id = ? AND user_id = ?', (event_id, session['user_id']))

        conn.commit()
        conn.close()

        flash('Event deleted successfully.')
        return redirect(url_for('home'))

    return redirect(url_for('login'))

@app.route('/update_event/<int:event_id>', methods=['GET', 'POST'])
def update_event(event_id):
    if 'user_id' in session:
        conn = get_db_connection()
        cur = conn.cursor()

        if request.method == 'POST':
            event_name = request.form['event_name']
            event_date = request.form['event_date']
            num_guests = int(request.form['num_guests'])

            # Update event details
            cur.execute('''
                UPDATE events
                SET event_name = ?, event_date = ?
                WHERE id = ? AND user_id = ?
            ''', (event_name, event_date, event_id, session['user_id']))

            # Delete existing guests for the event
            cur.execute('DELETE FROM guests WHERE event_id = ?', (event_id,))

            # Insert new guests
            for i in range(num_guests):
                guest_name = request.form.get(f'guest_name_{i}')
                phone_number = request.form.get(f'phone_number_{i}')
                email = request.form.get(f'email_{i}')
                
                cur.execute('''
                    INSERT INTO guests (event_id, guest_name, phone_number, email, user_id)
                    VALUES (?, ?, ?, ?, ?)
                ''', (event_id, guest_name, phone_number, email, session['user_id']))

            conn.commit()
            conn.close()

            flash('Event updated successfully.')
            return redirect(url_for('home'))

        # Fetch event details and guests
        cur.execute('SELECT * FROM events WHERE id = ? AND user_id = ?', (event_id, session['user_id']))
        event = cur.fetchone()

        cur.execute('SELECT * FROM guests WHERE event_id = ?', (event_id,))
        guests = cur.fetchall()

        conn.close()

        # Convert rows to dictionaries
        event = dict(event) if event else {}
        guests = [dict(guest) for guest in guests]

        if event:
            return render_template('update_event.html', event=event, guests=guests)

    return redirect(url_for('login'))

# Admin Registration Route
@app.route('/admin_register', methods=['GET', 'POST'])
def admin_register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        conn = get_db_connection()
        cur = conn.cursor()

        # Check if email already exists
        cur.execute('SELECT * FROM admins WHERE email = ?', (email,))
        admin = cur.fetchone()

        if admin:
            flash('Email already registered.')
            return redirect(url_for('admin_register'))

        # Insert admin into the database
        cur.execute('INSERT INTO admins (name, email, password) VALUES (?, ?, ?)', 
                    (name, email, hashed_password))
        conn.commit()
        conn.close()

        flash('Registration successful. Please log in.')
        return redirect(url_for('admin_login'))

    return render_template('admin_register.html')

# Admin Login Route
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM admins WHERE email = ?', (email,))
        admin = cur.fetchone()

        if admin and check_password_hash(admin['password'], password):
            session['admin_id'] = admin['id']
            session['admin_name'] = admin['name']
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid email or password.')

    return render_template('admin_login.html')

# Admin Dashboard Route
@app.route('/admin_dashboard')
def admin_dashboard():
    if 'admin_id' in session:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM admins WHERE id = ?', (session['admin_id'],))
        admin = cur.fetchone()
        conn.close()
        return render_template('admin_dashboard.html', admin=admin)
    else:
        return redirect(url_for('admin_login'))

@app.route('/admin/logout', methods=['POST'])
def admin_logout():
    # Remove admin session data
    session.pop('admin_id', None)
    session.pop('admin_name', None)
    flash('You have been logged out successfully.', 'success')
    return redirect(url_for('admin_login'))


# Route to view all users
@app.route('/admin/users')
def admin_users():
    if 'admin_id' in session:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM users')
        users = cur.fetchall()
        conn.close()
        return render_template('admin_users.html', users=users)
    else:
        return redirect(url_for('admin_login'))

# Route to view all vendors
@app.route('/admin/vendors')
def admin_vendors():
    if 'admin_id' in session:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM vendors')
        vendors = cur.fetchall()
        conn.close()
        return render_template('admin_vendors.html', vendors=vendors)
    else:
        return redirect(url_for('admin_login'))

# Route to update user
@app.route('/admin/update_user/<int:user_id>', methods=['GET', 'POST'])
def update_user(user_id):
    if 'admin_id' in session:
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST':
            name = request.form['name']
            email = request.form['email']
            cur.execute('UPDATE users SET name = ?, email = ? WHERE id = ?', (name, email, user_id))
            conn.commit()
            conn.close()
            flash('User updated successfully!')
            return redirect(url_for('admin_users'))
        cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        user = cur.fetchone()
        conn.close()
        return render_template('update_user.html', user=user)
    else:
        return redirect(url_for('admin_login'))

# Route to delete user
@app.route('/admin/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    if 'admin_id' in session:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('DELETE FROM users WHERE id = ?', (user_id,))
        conn.commit()
        conn.close()
        flash('User deleted successfully!')
        return redirect(url_for('admin_users'))
    else:
        return redirect(url_for('admin_login'))

# Route to update vendor
@app.route('/admin/update_vendor/<int:vendor_id>', methods=['GET', 'POST'])
def update_vendor(vendor_id):
    if 'admin_id' in session:
        conn = get_db_connection()
        cur = conn.cursor()
        if request.method == 'POST':
            name = request.form['name']
            email = request.form['email']
            category = request.form['category']
            cur.execute('UPDATE vendors SET name = ?, email = ?, category = ? WHERE id = ?', 
                        (name, email, category, vendor_id))
            conn.commit()
            conn.close()
            flash('Vendor updated successfully!')
            return redirect(url_for('admin_vendors'))
        cur.execute('SELECT * FROM vendors WHERE id = ?', (vendor_id,))
        vendor = cur.fetchone()
        conn.close()
        return render_template('update_vendor.html', vendor=vendor)
    else:
        return redirect(url_for('admin_login'))

# Route to delete vendor
@app.route('/admin/delete_vendor/<int:vendor_id>', methods=['POST'])
def delete_vendor(vendor_id):
    if 'admin_id' in session:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('DELETE FROM vendors WHERE id = ?', (vendor_id,))
        conn.commit()
        conn.close()
        flash('Vendor deleted successfully!')
        return redirect(url_for('admin_vendors'))
    else:
        return redirect(url_for('admin_login'))


@app.route('/products')
def products():
    conn = get_db_connection()
    cur = conn.cursor()
    
    # Fetch all items from the 'items' table
    cur.execute('SELECT * FROM items')
    items = cur.fetchall()

    # Get the user ID from the session
    cart_count = 0
    if 'user_id' in session:
        user_id = session['user_id']
        cur.execute('SELECT SUM(quantity) FROM cart WHERE user_id = ?', (user_id,))
        cart_count_result = cur.fetchone()
        cart_count = cart_count_result[0] if cart_count_result[0] else 0
    
    conn.close()
    return render_template('products.html', items=items, cart_count=cart_count)


@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    user_id = request.form['user_id']  # Assume user_id is provided in the form
    item_id = request.form['item_id']   # The ID of the item being added
    quantity = request.form['quantity']   # Quantity of the item

    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO cart (user_id, item_id, quantity) VALUES (?, ?, ?)', (user_id, item_id, quantity))
    conn.commit()
    conn.close()

    return redirect(url_for('products'))  # Redirect to index or another page

@app.route('/cart')
def view_cart():
    if 'user_id' in session:
        user_id = session['user_id']
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Fetch cart items with product details
        cursor.execute('''
            SELECT cart.item_id, cart.quantity, items.product_name, items.product_price 
            FROM cart 
            JOIN items ON cart.item_id = items.id 
            WHERE cart.user_id = ?
        ''', (user_id,))
        cart_items = cursor.fetchall()
        
        # Calculate total price
        total_price = sum(item[1] * item[3] for item in cart_items)  # quantity * price
        conn.close()
        
        return render_template('cart.html', cart_items=cart_items, total_price=total_price)
    else:
        flash('Please log in to view your cart.', 'warning')
        return redirect(url_for('login'))  # Redirect to login or home page

@app.route('/buy_now', methods=['POST'])
def buy_now():
    if 'user_id' in session:
        user_id = session['user_id']
        # Logic to process the purchase (e.g., store order details)

        # Clear the cart after purchase (optional)
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM cart WHERE user_id = ?', (user_id,))
        conn.commit()
        conn.close()

        # Flash a message to indicate the order has been placed
        flash('Order has been placed!', 'success')
        
        return redirect(url_for('view_cart'))  # Redirect to cart page or a confirmation page
    else:
        flash('Please log in to place an order.', 'warning')
        return redirect(url_for('login'))  # Redirect to login or home page


if __name__ == '__main__':
    app.run(debug=True)
